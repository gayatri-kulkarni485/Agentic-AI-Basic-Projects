from langchain_huggingface import ChatHuggingFace, HuggingFaceEndpoint
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import PromptTemplate
from dotenv import load_dotenv

load_dotenv()

# Hugging Face endpoint
llm = HuggingFaceEndpoint(
    repo_id="meta-llama/Llama-3.1-8B-Instruct",
    task="text-generation"
)

# Convert endpoint into chat model
model = ChatHuggingFace(llm=llm)

# Prompt 1
prompt1 = PromptTemplate(
    template="Who is the best cricket player of {country}? Give only 1 name.",
    input_variables=["country"]
)

# Prompt 2
prompt2 = PromptTemplate(
    template="Write an interesting fact about {cricketer}.",
    input_variables=["cricketer"]
)

parser = StrOutputParser()

# Chain
chain = prompt1 | model | parser

result1 = chain.invoke({"country": "India"})

print(result1)