from dotenv import load_dotenv

from langchain_huggingface import ChatHuggingFace, HuggingFaceEndpoint
from langchain_core.tools import tool
from langchain_core.messages import HumanMessage, AIMessage
from langchain_community.tools import DuckDuckGoSearchRun
from langchain.agents import create_agent


load_dotenv()


# Calculator Tools

@tool
def add(a: float, b: float) -> float:
    """Add two numbers together."""
    return a + b


@tool
def subtract(a: float, b: float) -> float:
    """Subtract the second number from the first."""
    return a - b


@tool
def multiply(a: float, b: float) -> float:
    """Multiply two numbers together."""
    return a * b


@tool
def divide(a: float, b: float):
    """Divide the first number by the second."""
    if b == 0:
        return "Error: Cannot divide by zero."
    return a / b


# Web Search Tool

search = DuckDuckGoSearchRun()


# Hugging Face Model

endpoint = HuggingFaceEndpoint(
    repo_id="meta-llama/Llama-3.1-8B-Instruct",
    task="text-generation",
)


model = ChatHuggingFace(
    llm=endpoint
)


# All Tools

tools = [
    add,
    subtract,
    multiply,
    divide,
    search
]


# Create Agent

agent = create_agent(
    model=model,
    tools=tools,
    system_prompt="""
You are a helpful AI assistant.

You have access to calculator tools and a web search tool.

Rules:
- Use calculator tools whenever mathematical calculation is needed.
- Use web search for current information or facts you are unsure about.
- If no tool is needed, answer directly.
"""
)


if __name__ == "__main__":

    print("Simple AI Assistant")
    print("Type 'exit' to quit.\n")

    chat_history = []

    while True:

        user_input = input("You: ")

        if user_input.lower() in ("exit", "quit"):
            break

        human_message = HumanMessage(
            content=user_input
        )

        chat_history.append(human_message)

        result = agent.invoke({
            "messages": chat_history
        })

        ai_message = result["messages"][-1]

        chat_history.append(
            AIMessage(content=ai_message.content)
        )

        print("\nAssistant:", ai_message.content, "\n")